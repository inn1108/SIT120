new Vue({
  el: '#app',
  data: {
      foods: [ 
          { "id": "Pizza", "name": "Pizza" }, 
          { "id": "Pasta", "name": "Pasta" }, 
          { "id": "Curry", "name": "Curry" }, 
          { "id": "Cake", "name": "Cake" }, 
          
      ],
      selected: [],
      allchoose: false,
      foodIds: []
  },
  methods: {
      chooseAll: function() {
          this.foodIds = [];

          if (this.allchoose) {
              for (food in this.foods) {
                  this.foodIds.push(this.foods[food].id.toString());
              }
          }
      },
      select: function() {
          this.allchoose = false;
      }
  }
})
