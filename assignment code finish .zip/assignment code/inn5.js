var quiz = {
    questions: [
      {
         text: "1. Please choose your gender?",
         responses: [
            { text: "Lady" },
            { text: "Men", correct: true },
            { text: "Other"}
              
         ]
      },
       {
          text: "2.	Do I work hard or study hard?",
          responses: [
             { text: "Never" },
             { text: "Occasionally," },
             { text: "Often" , correct: true }
          ]
       },
       {
          text: "3.	I've been strong in my life, you know?",
          responses: [
             { text: "Never" },
             { text: "Every day", correct: true },
             { text: "Occasionally" }
          ]
       },
       {
          text: "4.  I'm really happy with my performance. I like who I am, you know?",
          responses: [
             { text: "Often", correct: true },
             { text: "Some Time" },
             { text: "Never"}
            
          ]
       },
       {
          text: "5.  I'm proud of what I do, you know?",
          responses: [
            { text: "Often", correct: true },
            { text: "Some Time" },
            { text: "Never"}
          ]
       },
       {
          text:"6. Am I a good thinker?",
          responses: [
            { text: "Often", correct: true },
            { text: "Some Time" },
            { text: "Never"}
          ]
       },
       {
          text: "7.  I was afraid that someone might hurt me when I was out?",
          responses: [
            { text: "Often", correct: true },
            { text: "Some Time" },
            { text: "Never"}
          ]
       },
       {
          text: "8.  I love and love my body, you know?",
          responses: [
            { text: "Often", correct: true },
            { text: "Some Time" },
            { text: "Never"}
          ]
       },
       {
          text: "9.  I would be horrified by my own nightmares?",
          responses: [
            { text: "Often", correct: true },
            { text: "Some Time" },
            { text: "Never"}
          ]
       },
       {
        text: "10. In work or study, I will worry",
        
          responses: [
            { text: "Often", correct: true },
            { text: "Some Time" },
            { text: "Never"}
          ]
       }
    ]
  },
  userResponseSkelaton = Array(quiz.questions.length).fill(null);


  var app = new Vue({
  el: "#app",
  data: {
    quiz: quiz,
    questionIndex: 0,
    userResponses: userResponseSkelaton,
    isActive: false
  },
  filters: {
    charIndex: function(i) {
       return String.fromCharCode(97 + i);
    }
  },
  methods: {
   restart: function(){
       this.questionIndex=0;
       this.userResponses=Array(this.quiz.questions.length).fill(null);
   },
    selectOption: function(index) {
       Vue.set(this.userResponses, this.questionIndex, index);
    },
    next: function() {
       if (this.questionIndex < this.quiz.questions.length)
          this.questionIndex++;
    },
    prev: function() {
       if (this.quiz.questions.length > 0) this.questionIndex--;
    },
    score: function() {
       var score = 0;
       for (let i = 0; i < this.userResponses.length; i++) {
          if (
             typeof this.quiz.questions[i].responses[
                this.userResponses[i]
             ] !== "undefined" &&
             this.quiz.questions[i].responses[this.userResponses[i]].correct
          ) {
             score = score + 1;
          }
       }
       return score;
  
    }
  }
  });