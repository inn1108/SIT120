
  var i=10;
  setInterval(function () {
      var a=document.querySelector("span");
          i--;
          a.innerHTML=i;
          if(i==0){
              location.href="inn5.html";
          }

  },1000)

