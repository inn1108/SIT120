var quiz = {
   questions: [
     {
        text: "1. 请选择你的性别?",
        responses: [
           { text: "女士" },
           { text: "男士", correct: true },
           { text: " 其他" }   
        ]
     },
      {
         text: "2.	在工作或者学习中，我会忧虑?",
         responses: [
            { text: "经常", correct: true },
            { text: "偶尔" },
            { text: "从来没有" }
         ]
      },
      {
         text: "3.	我会想到一些可怕的事情",
         responses: [
           { text: "经常", correct: true },
           { text: "偶尔" },
           { text: "从来没有" }
         ]
      },
      {
         text: "4.  我担心别人会取笑我",
         responses: [
           { text: "经常", correct: true },
           { text: "偶尔" },
           { text: "从来没有" }
           
         ]
      },
      {
         text: "5.  我害怕自己会犯错",
         responses: [
           { text: "经常", correct: true },
           { text: "偶尔" },
           { text: "从来没有" }
         ]
      },
      {
         text:"6. 我害怕自己会受伤害",
         responses: [
           { text: "经常", correct: true },
           { text: "偶尔" },
           { text: "从来没有" }
         ]
      },
      {
         text: "7.  我十分担心自己业绩或者成绩变差",
         responses: [
           { text: "经常", correct: true },
           { text: "偶尔" },
           { text: "从来没有" }
         ]
      },
      {
         text: "8.  我对未来很忧虑?",
         responses: [
           { text: "经常", correct: true },
           { text: "偶尔" },
           { text: "从来没有" }
         ]
      },
      {
         text: "9. 我的手会忍不住颤抖",
         responses: [
           { text: "经常", correct: true },
           { text: "偶尔" },
           { text: "从来没有" }
         ]
      },
      {
       text: "10.  我担心自己会发疯",
       
         responses: [
           { text: "经常", correct: true },
           { text: "偶尔" },
           { text: "从来没有" }
         ]
      }
   ]
 },
 userResponseSkelaton = Array(quiz.questions.length).fill(null);


  var app = new Vue({
  el: "#app",
  data: {
    quiz: quiz,
    questionIndex: 0,
    userResponses: userResponseSkelaton,
    isActive: false
  },
  filters: {
    charIndex: function(i) {
       return String.fromCharCode(97 + i);
    }
  },
  methods: {

    selectOption: function(index) {
       Vue.set(this.userResponses, this.questionIndex, index);
    },
    next: function() {
       if (this.questionIndex < this.quiz.questions.length)
          this.questionIndex++;
    },
    prev: function() {
       if (this.quiz.questions.length > 0) this.questionIndex--;
    },
    score: function() {
       var score = 0;
       for (let i = 0; i < this.userResponses.length; i++) {
          if (
             typeof this.quiz.questions[i].responses[
                this.userResponses[i]
             ] !== "undefined" &&
             this.quiz.questions[i].responses[this.userResponses[i]].correct
          ) {
             score = score + 1;
          }
       }
       return score;
  
    }
  }
  });